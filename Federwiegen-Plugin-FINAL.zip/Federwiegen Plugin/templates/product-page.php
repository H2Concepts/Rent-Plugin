<?php
global $wpdb;

// Get category data
$category_id = isset($category) ? $category->id : 1;

// Get all data for this category
$variants = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_variants WHERE category_id = %d AND active = 1 ORDER BY sort_order",
    $category_id
));

$extras = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_extras WHERE category_id = %d AND active = 1 ORDER BY sort_order",
    $category_id
));

$durations = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_durations WHERE category_id = %d AND active = 1 ORDER BY sort_order",
    $category_id
));

// Get category settings
$default_image = isset($category) ? $category->default_image : '';
$product_title = isset($category) ? $category->product_title : 'Premium Federwiegen';
$product_description = isset($category) ? $category->product_description : 'Unsere Federwiegen bieten Ihrem Baby die natürliche Wiegebewegung, die es aus dem Mutterleib kennt. Dies fördert einen ruhigen Schlaf und gibt Ihnen als Eltern wertvolle Erholung.';

// Features
$features_title = isset($category) ? ($category->features_title ?? 'Warum unsere Federwiegen?') : 'Warum unsere Federwiegen?';
$feature_1_icon = isset($category) ? $category->feature_1_icon : '';
$feature_1_title = isset($category) ? $category->feature_1_title : 'Sicherheit First';
$feature_1_description = isset($category) ? $category->feature_1_description : 'Alle unsere Produkte sind nach höchsten Sicherheitsstandards geprüft und zertifiziert.';
$feature_2_icon = isset($category) ? $category->feature_2_icon : '';
$feature_2_title = isset($category) ? $category->feature_2_title : 'Liebevolle Pflege';
$feature_2_description = isset($category) ? $category->feature_2_description : 'Jede Federwiege wird nach der Rückgabe professionell gereinigt und desinfiziert.';
$feature_3_icon = isset($category) ? $category->feature_3_icon : '';
$feature_3_title = isset($category) ? $category->feature_3_title : 'Modern & Smart';
$feature_3_description = isset($category) ? $category->feature_3_description : 'Optional mit App-Steuerung für maximalen Komfort im Alltag.';

// Button
$button_text = isset($category) ? $category->button_text : 'Jetzt Mieten';
$button_icon = isset($category) ? $category->button_icon : '';

// Shipping
$shipping_cost = isset($category) ? ($category->shipping_cost ?? 9.99) : 9.99;

// Layout
$layout_style = isset($category) ? ($category->layout_style ?? 'default') : 'default';

// Tooltips
$duration_tooltip = isset($category) ? ($category->duration_tooltip ?? 'Nach der Mindestmietdauer kannst Du dein Abo jederzeit kündigen oder auf ein anderes Produkt wechseln.') : 'Nach der Mindestmietdauer kannst Du dein Abo jederzeit kündigen oder auf ein anderes Produkt wechseln.';
$condition_tooltip = isset($category) ? ($category->condition_tooltip ?? "Neu: Neue, originalverpackte Produkte.\n\nAufbereitet: Bereits benutzte Produkte, die von uns gereinigt, desinfiziert, repariert und in Top-Zustand gebracht wurden.\n\nWeitere Informationen findest du im Helpcenter.") : "Neu: Neue, originalverpackte Produkte.\n\nAufbereitet: Bereits benutzte Produkte, die von uns gereinigt, desinfiziert, repariert und in Top-Zustand gebracht wurden.\n\nWeitere Informationen findest du im Helpcenter.";

// Get initial conditions and colors (will be updated via AJAX when variant is selected)
$initial_conditions = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_conditions WHERE category_id = %d AND active = 1 AND available = 1 ORDER BY sort_order",
    $category_id
));

$initial_product_colors = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_colors WHERE category_id = %d AND color_type = 'product' AND active = 1 AND available = 1 ORDER BY sort_order",
    $category_id
));

$initial_frame_colors = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}federwiegen_colors WHERE category_id = %d AND color_type = 'frame' AND active = 1 AND available = 1 ORDER BY sort_order",
    $category_id
));
?>

<div class="federwiegen-container" data-category-id="<?php echo $category_id; ?>" data-layout="<?php echo esc_attr($layout_style); ?>">
    <div class="federwiegen-header">
        <div class="federwiegen-icon">👶</div>
        <h1><?php echo esc_html($page_title); ?></h1>
        <p class="federwiegen-description"><?php echo esc_html($page_description); ?></p>
    </div>

    <div class="federwiegen-content">
        <div class="federwiegen-left">
            <div class="federwiegen-product-info">
                <div class="federwiegen-product-image">
                    <div class="federwiegen-image-gallery" id="federwiegen-image-gallery">
                        <!-- Main Image Container -->
                        <div class="federwiegen-main-image-container" id="federwiegen-main-image-container">
                            <?php if (!empty($default_image)): ?>
                                <img src="<?php echo esc_url($default_image); ?>" alt="Federwiege" id="federwiegen-main-image" class="federwiegen-main-image">
                            <?php else: ?>
                                <div class="federwiegen-placeholder-image" id="federwiegen-placeholder">👶</div>
                            <?php endif; ?>
                            
                            <!-- Extra Image Overlay -->
                            <div class="federwiegen-extra-overlay" id="federwiegen-extra-overlay" style="display: none;">
                                <img src="" alt="Extra" id="federwiegen-extra-image" class="federwiegen-extra-image">
                            </div>
                        </div>
                        
                        <!-- Thumbnail Navigation -->
                        <div class="federwiegen-thumbnails" id="federwiegen-thumbnails" style="display: none;">
                            <!-- Thumbnails will be populated by JavaScript -->
                        </div>
                    </div>
                </div>
                
                <div class="federwiegen-product-details">
                    <h2><?php echo esc_html($product_title); ?></h2>
                    <p><?php echo esc_html($product_description); ?></p>
                    
                    <div class="federwiegen-features">
                        <div class="federwiegen-feature">
                            <span class="federwiegen-feature-icon">🛡️</span>
                            <span>Sicherheitsgeprüft</span>
                        </div>
                        <div class="federwiegen-feature">
                            <span class="federwiegen-feature-icon">❤️</span>
                            <span>Baby-gerecht</span>
                        </div>
                        <div class="federwiegen-feature">
                            <span class="federwiegen-feature-icon">📱</span>
                            <span>App-Steuerung</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="federwiegen-price-display" id="federwiegen-price-display" style="display: none;">
                <div class="federwiegen-price-content">
                    <p class="federwiegen-price-label">Monatlicher Mietpreis</p>
                    <div class="federwiegen-price-wrapper">
                        <span class="federwiegen-original-price" id="federwiegen-original-price" style="display: none;"></span>
                        <span class="federwiegen-final-price" id="federwiegen-final-price">0,00€</span>
                        <span class="federwiegen-price-period">/Monat</span>
                    </div>
                    <p class="federwiegen-savings" id="federwiegen-savings" style="display: none;"></p>
                    <div class="federwiegen-shipping-info">
                        <p class="federwiegen-shipping-text">
                            <span class="federwiegen-shipping-icon">🚚</span>
                            Einmalige Versandkosten: <strong><?php echo number_format($shipping_cost, 2, ',', '.'); ?>€</strong>
                        </p>
                    </div>
                </div>
                <div class="federwiegen-price-icon">💶</div>
            </div>
        </div>

        <div class="federwiegen-right">
            <div class="federwiegen-configuration">
                <!-- Variants Selection -->
                <?php if (!empty($variants)): ?>
                <div class="federwiegen-section">
                    <h3>Wählen Sie Ihre Ausführung</h3>
                    <div class="federwiegen-options variants layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($variants as $variant): ?>
                        <div class="federwiegen-option <?php echo !($variant->available ?? 1) ? 'unavailable' : ''; ?>" 
                             data-type="variant" 
                             data-id="<?php echo $variant->id; ?>" 
                             data-available="<?php echo ($variant->available ?? 1) ? 'true' : 'false'; ?>"
                             data-images="<?php echo esc_attr(json_encode(array(
                                 $variant->image_url_1 ?? '',
                                 $variant->image_url_2 ?? '',
                                 $variant->image_url_3 ?? '',
                                 $variant->image_url_4 ?? '',
                                 $variant->image_url_5 ?? ''
                             ))); ?>">
                            <div class="federwiegen-option-content">
                                <h4><?php echo esc_html($variant->name); ?></h4>
                                <p><?php echo esc_html($variant->description); ?></p>
                                <p class="federwiegen-option-price">ab <?php echo number_format($variant->base_price, 2, ',', '.'); ?>€/Monat</p>
                                <?php if (!($variant->available ?? 1)): ?>
                                    <div class="federwiegen-availability-notice">
                                        <span class="federwiegen-unavailable-badge">❌ Nicht verfügbar</span>
                                        <?php if (!empty($variant->availability_note)): ?>
                                            <p class="federwiegen-availability-note"><?php echo esc_html($variant->availability_note); ?></p>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Extras Selection -->
                <?php if (!empty($extras)): ?>
                <div class="federwiegen-section">
                    <h3>Wählen Sie Ihr Extra</h3>
                    <div class="federwiegen-options extras layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($extras as $extra): ?>
                        <div class="federwiegen-option" data-type="extra" data-id="<?php echo $extra->id; ?>" 
                             data-extra-image="<?php echo esc_attr($extra->image_url ?? ''); ?>">
                            <div class="federwiegen-option-content">
                                <span class="federwiegen-extra-name"><?php echo esc_html($extra->name); ?></span>
                                <?php if ($extra->price > 0): ?>
                                <div class="federwiegen-extra-price">+<?php echo number_format($extra->price, 2, ',', '.'); ?>€/Monat</div>
                                <?php endif; ?>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Duration Selection -->
                <?php if (!empty($durations)): ?>
                <div class="federwiegen-section">
                    <h3>
                        Wählen Sie Ihre Mietdauer
                        <span class="federwiegen-tooltip">
                            ℹ️
                            <span class="federwiegen-tooltiptext"><?php echo esc_html($duration_tooltip); ?></span>
                        </span>
                    </h3>
                    <div class="federwiegen-options durations layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($durations as $duration): ?>
                        <div class="federwiegen-option" data-type="duration" data-id="<?php echo $duration->id; ?>">
                            <div class="federwiegen-option-content">
                                <div class="federwiegen-duration-header">
                                    <span class="federwiegen-duration-name"><?php echo esc_html($duration->name); ?></span>
                                    <?php if ($duration->discount > 0): ?>
                                    <span class="federwiegen-discount-badge">-<?php echo round($duration->discount * 100); ?>%</span>
                                    <?php endif; ?>
                                </div>
                                <p class="federwiegen-duration-info">
                                    Mindestlaufzeit: <?php echo $duration->months_minimum; ?> Monat<?php echo $duration->months_minimum > 1 ? 'e' : ''; ?>
                                </p>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Condition Selection (initially populated, will be updated via AJAX) -->
                <div class="federwiegen-section" id="condition-section" style="<?php echo empty($initial_conditions) ? 'display: none;' : ''; ?>">
                    <h3>
                        Zustand
                        <span class="federwiegen-tooltip">
                            ℹ️
                            <span class="federwiegen-tooltiptext"><?php echo esc_html($condition_tooltip); ?></span>
                        </span>
                    </h3>
                    <div class="federwiegen-options conditions layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($initial_conditions as $condition): ?>
                        <div class="federwiegen-option" data-type="condition" data-id="<?php echo $condition->id; ?>">
                            <div class="federwiegen-option-content">
                                <div class="federwiegen-condition-header">
                                    <span class="federwiegen-condition-name"><?php echo esc_html($condition->name); ?></span>
                                    <?php if ($condition->price_modifier != 0): ?>
                                    <span class="federwiegen-condition-badge">
                                        <?php echo $condition->price_modifier > 0 ? '+' : ''; ?><?php echo round($condition->price_modifier * 100); ?>%
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <p class="federwiegen-condition-info"><?php echo esc_html($condition->description); ?></p>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Product Color Selection (initially populated, will be updated via AJAX) -->
                <div class="federwiegen-section" id="product-color-section" style="<?php echo empty($initial_product_colors) ? 'display: none;' : ''; ?>">
                    <h3>Produktfarbe</h3>
                    <div class="federwiegen-options product-colors layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($initial_product_colors as $color): ?>
                        <div class="federwiegen-option" data-type="product-color" data-id="<?php echo $color->id; ?>">
                            <div class="federwiegen-option-content">
                                <div class="federwiegen-color-display">
                                    <div class="federwiegen-color-preview" style="background-color: <?php echo esc_attr($color->color_code); ?>;"></div>
                                    <span class="federwiegen-color-name"><?php echo esc_html($color->name); ?></span>
                                </div>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Frame Color Selection (initially populated, will be updated via AJAX) -->
                <div class="federwiegen-section" id="frame-color-section" style="<?php echo empty($initial_frame_colors) ? 'display: none;' : ''; ?>">
                    <h3>Gestellfarbe</h3>
                    <div class="federwiegen-options frame-colors layout-<?php echo esc_attr($layout_style); ?>">
                        <?php foreach ($initial_frame_colors as $color): ?>
                        <div class="federwiegen-option" data-type="frame-color" data-id="<?php echo $color->id; ?>">
                            <div class="federwiegen-option-content">
                                <div class="federwiegen-color-display">
                                    <div class="federwiegen-color-preview" style="background-color: <?php echo esc_attr($color->color_code); ?>;"></div>
                                    <span class="federwiegen-color-name"><?php echo esc_html($color->name); ?></span>
                                </div>
                            </div>
                            <div class="federwiegen-option-check">✓</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Rent Button -->
                <div class="federwiegen-button-section">
                    <?php 
                    $required_selections = array();
                    if (!empty($variants)) $required_selections[] = 'variant';
                    if (!empty($extras)) $required_selections[] = 'extra';
                    if (!empty($durations)) $required_selections[] = 'duration';
                    // Note: conditions and colors are optional and will be checked dynamically
                    ?>
                    
                    <?php if (!empty($required_selections)): ?>
                    <button id="federwiegen-rent-button" class="federwiegen-rent-button" disabled>
                        <?php if (!empty($button_icon)): ?>
                            <img src="<?php echo esc_url($button_icon); ?>" alt="Button Icon" class="federwiegen-button-icon-img">
                        <?php else: ?>
                            <span class="federwiegen-button-icon">🛒</span>
                        <?php endif; ?>
                        <span><?php echo esc_html($button_text); ?></span>
                    </button>
                    <p class="federwiegen-button-help" id="federwiegen-button-help">
                        Bitte treffen Sie alle Auswahlen um fortzufahren
                    </p>
                    <p class="federwiegen-unavailable-help" id="federwiegen-unavailable-help" style="display: none;">
                        Das gewählte Produkt ist aktuell nicht verfügbar
                    </p>
                    <?php else: ?>
                    <div style="padding: 20px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px; text-align: center;">
                        <h4>⚠️ Kategorie noch nicht vollständig konfiguriert</h4>
                        <p>Für diese Produktkategorie sind noch nicht alle erforderlichen Daten hinterlegt.</p>
                        <p><strong>Bitte konfigurieren Sie die fehlenden Daten im Admin-Bereich.</strong></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Features Section -->
    <div class="federwiegen-features-section">
        <h3><?php echo esc_html($features_title); ?></h3>
        <div class="federwiegen-features-grid">
            <div class="federwiegen-feature-item">
                <div class="federwiegen-feature-icon-large">
                    <?php if (!empty($feature_1_icon)): ?>
                        <img src="<?php echo esc_url($feature_1_icon); ?>" alt="<?php echo esc_attr($feature_1_title); ?>" style="width: 100%; height: 100%; object-fit: contain;">
                    <?php else: ?>
                        🛡️
                    <?php endif; ?>
                </div>
                <h4><?php echo esc_html($feature_1_title); ?></h4>
                <p><?php echo esc_html($feature_1_description); ?></p>
            </div>
            <div class="federwiegen-feature-item">
                <div class="federwiegen-feature-icon-large">
                    <?php if (!empty($feature_2_icon)): ?>
                        <img src="<?php echo esc_url($feature_2_icon); ?>" alt="<?php echo esc_attr($feature_2_title); ?>" style="width: 100%; height: 100%; object-fit: contain;">
                    <?php else: ?>
                        ❤️
                    <?php endif; ?>
                </div>
                <h4><?php echo esc_html($feature_2_title); ?></h4>
                <p><?php echo esc_html($feature_2_description); ?></p>
            </div>
            <div class="federwiegen-feature-item">
                <div class="federwiegen-feature-icon-large">
                    <?php if (!empty($feature_3_icon)): ?>
                        <img src="<?php echo esc_url($feature_3_icon); ?>" alt="<?php echo esc_attr($feature_3_title); ?>" style="width: 100%; height: 100%; object-fit: contain;">
                    <?php else: ?>
                        📱
                    <?php endif; ?>
                </div>
                <h4><?php echo esc_html($feature_3_title); ?></h4>
                <p><?php echo esc_html($feature_3_description); ?></p>
            </div>
        </div>
    </div>
</div>